from telethon import events
import asyncio
import os
import sys
import random
from userbot.utils import admin_cmd

@borg.on(admin_cmd(pattern=r"gf$", outgoing=True))
async def _(event):
    if event.fwd_from:
        return
    animation_interval = 5
    animation_ttl = range(0, 21)  
    animation_chars = [
        
            "`Ruk jaa , Abhi teri GF ko Fuck karta hu `",
            "`Making your Gf warm 🔥`",
            "`Pressing her boobs 🤚😘`",
            "`Stimulating her pussy🖕`",
            "`Fingering her pussy 💧😍👅 `",
            "`Asking her to taste my DICK🍌`",
            "`Requested accepted😻💋, Ready to taste my DICK🍌`",
            "`Getting her ready to fuck 👀`",
            "`Your GF Is Ready To Fuck`",
            "`Fucking Your GF😈😈\n\n\nYour GF's Pussy Get Red\nTrying new SEX position to make her Squirt\n\nAlmost Done. 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Fucking Your GF😈😈\n\n\nYour GF's Pussy Get White\nShe squirted like a shower💧💦👅\n\nAlmost Done..\n\nFucked Percentage... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Fucking Your GF😈😈\n\n\nYour GF's Pussy Get Red\nDoing Extreme SEX with her👄\n\nAlmost Done...\n\nFucked Percentage... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Fucking Your GF😈😈\n\n\nYour GF's Pussy Get Red\nWarming her Ass🍑 to Fuck!🍑🍑\n\nAlmost Done....\n\nFucked Percentage... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Fucking Your GF😈😈\n\n\nYour GF's ASS🍑 Get Red\nInserted my Penis🍌 in her ASS🍑\n\nAlmost Done.....\n\nFucked Percentage... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Fucking Your GF😈😈\n\n\nYour GF's ASS🍑 Get Red\ndoing extreme sex with her\n\nAlmost Done......\n\nFucked Percentage... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `",
            "`Fucking Your GF😈😈\n\n\nYour GF's Boobs🤚😘 are Awesome\nPressing her tight Nipples🤚👀\n\nAlmost Done.......\n\nFucked Percentage... 84%\n███████████████████▒▒▒▒▒▒ `",
            "`Fucking Your GF😈😈\n\n\nYour GF's Lips Get Horny\nDoing French Kiss with your GF👄💋\n\nAlmost Done........\n\nFucked Percentage... 89%\n██████████████████████▒▒▒ `",
            "`Fucking Your GF😈😈\n\n\nYour GF's Boobs🤚😘 are Awesome\nI am getting ready to cum in her Mouth👄\n\nAlmost Done.......\n\nFucked Percentage... 90%\n██████████████████████▒▒▒ `",
            "`Fucking Your GF😈😈\n\n\nYour GF's Boobs🤚😘 are Awesome\nFinally, I have cummed in her Mouth👅👄\n\nAlmost Done.......\n\nFucked Percentage... 96%\n████████████████████████▒ `",
            "`Fucking Your GF😈😈\n\n\nYour GF's is Awesome\nShe is Licking my Dick🍌 in the Awesome Way✊🤛🤛👅👄\n\nAlmost Done.......\n\nFucked Percentage... 100%\n█████████████████████████ `",
            "`Fucking Your GF😈😈\n\n\nYour GF's ASS🍑 Get Red\nCummed On her Mouth👅👄\n\nYour GF got Pleasure\n\nResult: Now I Have 1 More SEX Partner 👍👍`"
        ]

    for i in animation_ttl:
            await asyncio.sleep(animation_interval)
            await event.edit(animation_chars[i % 21])

@borg.on(admin_cmd(pattern=r"xtx$", outgoing=True))
async def _(event):
    if event.fwd_from:
        return
    await event.edit("അച്ഛനെ കണ്ടു പിടിക്കുന്നു....")
    await asyncio.sleep(2)
    x=(random.randrange(1,33))
    if x==1:
        await event.edit("pha.... കള്ള കാവടി അറുവാണി തള്ളേ ഒത്ത തായോളി")
    if x==2:
        await event.edit("നീ പോയി നിന്റെ അമ്മടെ പൂറ്റിലും കുതിയിലും അടിക്ക് കടി മാറട്ടെ ഇടക്ക് റസ്റ്റ്‌ കൊടുത്തോളൂ")
    if x==3:
        await event.edit("ചൊറിയാൻ പട്ടി ഒത്തു ഉണ്ടായ ബംഗാളി പൂറി നിനക്കു വീട്ടിൽ പോയി തള്ള എന്ത് ചെയ്യുന്നു എന്ന് നോക്കികൂടെ")
    if x==4:
        await event.edit("നിന്റെ അമ്മക്കും പെങ്ങൾക്കും കൂടി 100 രൂപ ഒക്കെ ആണെങ്കിൽ ഞാൻ വരാം ഇല്ലെങ്കിൽ നീ നിന്റെ അച്ഛന്റെ തീട്ടം തിന്നു വിഷമം മാറ്റിക്കോ")
    if x==5:
        await event.edit("പാൽ കുപ്പി മൈരൻ കുണ്ണയൊളി നിന്റെ അച്ഛന്റെ അണ്ടി കിട്ടിയില്ലേ നിനക്കു കിടന്ന് കരയാൻ")
    if x==6:
        await event.edit("പോയി ആസനത്തിൽ മുളക് തേച്ചു കുളിക്ക്")
    if x==7:
        await event.edit("നിന്റെ അമ്മേടെ വേടല പൂറ്റിൽ ഞാൻ കോലിട്ടു എളക്കും മൈരേ")    
    if x==8:
        await event.edit("എടാ പോടാ വെപ്പണ്ടി മൈരേ തള്ളേ ഒത്ത തായൊളി....")
    if x==9:
        await event.edit("കുനിഞ്ഞു നിന്നു ഊമ്പിക്കോ മൈരേ നിന്റെ അമ്മേടെ സെറ്റപ്പ് ഞാൻ അതിനും നീ കിടന്നു കരഞ്ഞോ....")
    if x==10:
        await event.edit("നിന്റെ തന്തേടെ വകയാണോ ടെലിഗ്രാം... പച്ചപൂറിമോനെ")     
    if x==11:
        await event.edit("നിന്റെ തള്ളേടെ കൂതി മൈരേ")
    if x==12:
        await event.edit("ആളും തരവും നോക്കി കളിക്കടാ പട്ടി ഓത്ത മൈരേ...")    
    if x==13:
        await event.edit("വവ്വാലിൻ കാട്ടം പൂറ്റിൽ വീണു മുളച്ച് ഉണ്ടായതോണോ വെടലകൂതി പുണ്ടച്ചി മോനെ നീ.....")
    if x==14:
        await event.edit("പണ്ട് നിന്റെ തന്തയുടെ അണ്ടി ഞാൻ അരിഞ്ഞെടുത്തപ്പോ പകരം വെച്ച പട്ടിയുടെ അണ്ടി കൊണ്ട് ഉണ്ടായതല്ലേ നീ നായിന്റെ മോനെ....")        
    if x==15:
        await event.edit("കുനിഞ്ഞിരുന്ന് നിന്റെ അണ്ടിയില്ലാത്ത തുടയിടുക്കിൽ വിരലിട്ടു നക്കിക്കോ മൈരേ....")
    if x==16:
        await event.edit("അതിനു നിന്നെ ജനിപ്പിച്ചപ്പോഴേ നിന്റെ അപ്പന്റെ അണ്ടി കരിഞ്ഞു പോയതല്ലേ മപ്പാസ് മൈരേ")     
    if x==17:
        await event.edit("വല്ലവന്റേം കുണ്ണ നിന്റെ കൊച്ചു കുണ്ണയ്ക്ക് അടിയിലൂടെ കണ്ടെന്ന് കരുതി വലിയ വർത്താനം പറയാതെ കൂത്തിച്ചി..... ")
    if x==18:
        await event.edit("പ്രസവിക്കുമ്പോ തള്ളേടെ പൂറ്റിൽ വത്സനടിച്ച നിനക്ക് ഒക്കെ പട്ടിടെ വിലയുണ്ടോ മുറി അണ്ടി പൂറാ....")
    if x==19:
        await event.edit("അപ്പൂപ്പൻ താടിക്ക് കറുത്ത പൈയിന്റടിച്ച് കുണ്ണ തലപ്പിൽ ഒട്ടിച്ച് വെച്ചാൽ വലിയ എന്തോ മൈരായി എന്ന നിന്റെ ഊമ്പിയ കോണയും കൊണ്ട് ഇവിടെ വന്നേക്കരുത്")
    if x==20:
        await event.edit("കുണ്ടനടിച്ച് കുണ്ടനടിച്ച് മതിയാവുമ്പോ നിന്റെ ഉണങ്ങിചുങ്ങിയ കുണ്ണ വെക്കാൻ ഇതു നിന്റെ അപ്പന്റെ അണ്ടിപ്പുര അല്ല....")
    if x==21:        
        await event.edit("ആണുങ്ങളെ കണ്ടാൽ നിന്റെ നാവ് ഇറങ്ങി പോയി നിന്റെ കുണ്ണ മാത്രേ പൊന്തുകയൊള്ളോ കുണ്ടനടി തായൊളി... ")        
    if x==22:        
        await event.edit("നിന്റെ അണ്ടിക്ക് വട്ടതാളം പിടിക്കാൻ കൊറേ പട്ടി ഓത്ത പൂറിമക്കൾ കാണും എന്നു വെച്ച് ആണുങ്ങൾടെ മേലോട്ട് കേറാൻ വന്നാൽ നിന്റെ ചെറുപഴം പോലത്തെ ആ പീക്കിരി കുണ്ണ ഒടിച്ച് കളയും മൈരേ....")       
    if x==23:
        await event.edit("കഴപ്പ് അത്രയ്ക്ക് ഉണ്ടേൽ പോയി വാഴയ്ക്ക് തുള ഇട്ടടിക്ക് പച്ചിലപൂറി കുണ്ടറോളി")
    if x==24:
        await event.edit("കിടന്ന് കരഞ്ഞോ കണ്ടംപറി കുണ്ടച്ചി മോനെ കട്ടു തായൊളി കുണ്ണ അവരാതി")
    if x==25:        
        await event.edit("വെറുതെ ഇരിക്കുമ്പോ തുണി ഇല്ലാതെ ഇരുന്ന് സ്വന്തം കുണ്ണ വായിൽ എടുത്ത സന്തോഷിക്")        
    if x==26:        
        await event.edit("നിന്റെ അമ്മേടെ പട്ടി ഒത്ത കരിഞ്ഞ കഞ്ഞി പൂറ് എടുത്ത് ചപ്പി വലിക്ക് അവരാതി...")        
    if x==27:        
        await event.edit("നിനക്ക് ഇനിയും കഴച്ചു നിക്കുവാണെങ്കിൽ മുള്ളു കമ്പി എടുത്ത് വലിച്ചു കമ്പിൽ ചുറ്റി കെട്ടി നിന്റെ മുതു പൂറിൽ കുത്തി കേറ്റ് വെപ്പണ്ടി തായൊളി")        
    if x==28:        
        await event.edit("നിന്റെ വിഷമം മാറ്റാൻ പറ്റുന്നില്ലെങ്കിൽ തന്തയെ വിളിച്ചു ചപ്പി തരാം എന്ന് പറ എന്നിട്ട് കമ്പി അടിച്ചു നീക്കുമ്പോൾ അതിൽ അമ്മിക്കല്ലു എടുത്ത് ഇട്....")
    if x==29:        
        await event.edit("കട്ടു കഴുവേറി കുണ്ണ അവരാതി കുണ്ടൻ തായൊളി നിന്റെ തള്ളയെ പണ്ണിയ താണ്ടിയ ഇത് വന്നു ഒന്നു വായിൽ എടുത്തിട്ട് പൊക്കോ...🤣🤣")        
    if x==30:        
        await event.edit("*ആറടി *കുറുവടി മുളവടി  എടുത്തു നീ ആദ്യം പോയി നിന്റെ തള്ളേടെ കവപൊട്ടിഒഴുകുന്ന നിന്റെ തള്ളേടെ വട്ടപൂറ്റിൽ നാലുതവണ കയറ്റി* *ഇറക്കി കൊടുത്തു വാ....🤣🤣🤣")    
    if x==31:        
        await event.edit("നിന്റെ അപ്പൻ എന്ന് പറയുന്ന വെപ്പണ്ടി മൈരാന് അവതില്ല അത് കൊണ്ട് നിന്റെ തള്ളതേവിടിച്ചി കരഞ്ഞു കാമം തിർക്കുവ പൂറി മോനെ നിന്നെ ഉണ്ടാക്കിയാപൂറിമോൾ അല്ലേ ഒന്നും പോയി ചെയ്തു കൊടുക്ക് ഇപ്പോൾ തന്നെ....🤣🤣🤣")        
    if x==32:        
        await event.edit("Ee pezhacha thayoli onnum penninu undayathalla etho patti thoori undaya krimi anu....🤣🤣🤣")
    if x==33:        
        await event.edit("കൊച്ചുഗോളങ്ങൾ തഴുകി കളിക്കും കൊച്ചു കുണ്ണ. ഓടി നടക്കുന്ന കുഷ്ഠം പിടിച്ച പട്ടിയുടെ കൂത്തിലെ തീട്ടം മണത്തു വാണം വിടുന്ന പറ പൂറിമോനെ കടിത്തീരാത്ത പൂറില് കപ്പ കയറ്റി രസിക്കുന്ന കൊച്ചു പൂറി. കാക്ക പിള്ളേർ തൂറിവച്ച തീട്ടം മുലയിൽ തേച്ചു athupine നക്കി എടുത്തു പിന്നെ കുണ്ണയിൽ തേച്ചു വാണം വിട്ടു കളിക്ക് കുണ്ണ. മുലകൾ വലിപ്പമില്ല എന്നു പറഞ്ഞു കരിക്കുവെട്ടി ഊമ്പിയ കൊച്ചുപൂറാ നീ ഒരുപാട് കരിക്കോത ഓലമൈരൻ പൂറി മോനെ. കടി തെററാതെ 11kv  ലൈൻ പിടിച്ചു കുണ്ണ പിടിക്കുന്നു കറന്റ്‌ പുണ്ടച്ചി. കപ്പ തരിപ്പൂരി പുണ്ടച്ചി")

@borg.on(admin_cmd(pattern=r"pyavam$", outgoing=True))
async def _(event):
    if event.fwd_from:
        return
    animation_interval = 3
    animation_ttl = range(0, 20)    
    animation_chars = [
        
            "**Finding User Info..**",
            "**Finding User Info....**",
            "**(1) തന്ത ഇല്ല തായൊളി**",
            "**(1) വെപ്പാണ്ടി തായൊളി*",
            "**(2) Finding this user main തായൊളി തരങ്ങൾ...**",
            "**(2) Finding this user main തന്ത ഇല്ല തരങ്ങൾ...*",
            "**(3) Fatherless: ☑️**",
            "**(3) Fatherless: ✅**",    
            "**(4) Son of street DOG: ☑️**",
            "**(4) Son of street DOG: ✅**",
            "**(5) വെപ്പാണ്ടി ഉപയോഗിക്കുന്നു: ☑️**",
            "**(5) വെപ്പാണ്ടി ഉപയോഗിക്കുന്നു: ✅**",
            "**(6) Eats Any ones shit: ☑️**",
            "**(6) Eats Any ones shit: ✅**",
            "**(7) Mother Fucker: ☑️**",
            "**(7) Mother Fucker: ✅**",
            "**(8) Checking with DNA: ☑️**",
            "**(8) DNA Matching: ✅**",
            "**ചുരുക്കി പറഞ്ഞ നിന്റെ 8 തന്തകളിൽ ഒരാൾ എന്റെ Master  ആണ്*",
            "**ശരിയായ തന്തയെ കണ്ടു പിടിച്ചതിൽ നീ സന്തോഷവാൻ ആണോ Options : YES & NO Otherwise നീ ഒരു തന്ത ഇല്ല കഴുവേറി ആണ്**"

 ]
    for i in animation_ttl:
            await asyncio.sleep(animation_interval)
            await event.edit(animation_chars[i % 20])